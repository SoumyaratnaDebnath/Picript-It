from _pyDependencies import *
from flask import Flask, render_template, request, redirect, send_file
from flaskwebgui import FlaskUI
import os
from PIL import Image
import numpy

IMAGE = '__operated__.png'   # global reference to the image

PASSWORD = '#'               # global reference to the password

app = Flask(__name__)  # instance of localhost
ui = FlaskUI(app)      # instance of app-mode

app.config["Image_UPLOADS"] = str(os.getcwd()+'/static/')  # path to static folder

@app.after_request
def add_header(r):
    # this function is to emulate the Developer Option -> Network -> Disable Cache
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

# home.html 
@app.route('/', methods=['GET', 'POST'])
def main():
	return render_template('home.html')

# this function is responsible for download operation
@app.route('/download', methods=['GET', 'POST'])
def download_file():
	p = app.config["Image_UPLOADS"]+IMAGE
	return send_file(p, as_attachment=True)

# home.html -> image-selected.html
@app.route('/image-selected', methods=['GET', 'POST'])
def image_selected():
	if(request.method == 'POST'):
		try:
			os.remove(IMAGE)
		except:
			pass
		try:
			mySrc=request.files['mySrc']
			mySrc.save(app.config["Image_UPLOADS"]+IMAGE)
		except:
			pass
		return render_template('image-selected.html')

# home.html -> image-selected.html -> encryption-passcode.html
@app.route('/passcode-before-encryption', methods=['GET', 'POST'])
def passcode_before_encryption():
	return render_template('encryption-passcode.html')	

# home.html -> image-selected.html -> decryption-passcode.html
@app.route('/passcode-before-decryption', methods=['GET', 'POST'])
def passcode_before_decryption():
	return render_template('decryption-passcode.html')	

# home.html -> image-selected.html -> encryption-passcode.html -> encrypt-image.html
@app.route('/encrypt-image', methods=['GET', 'POST'])
def encrypt_selected():
	global PASSWORD
	try:
		os.chdir(str(app.config["Image_UPLOADS"]))
	except:
		pass
	if(request.method == 'POST'):
		PASSWORD = request.form['_password1']+request.form['_password2']+request.form['_password3']+request.form['_password4']+request.form['_password5']
		maxLen = get_maxLength(path = IMAGE)
		return render_template('encrypt-image.html', _maxLen_ = maxLen)

# home.html -> image-selected.html -> decryption-passcode.html -> unencripted-image.html/decrypt-image.html
@app.route('/decrypt-image', methods=['GET', 'POST'])
def decrypt_selected():
	try:
		os.chdir(str(app.config["Image_UPLOADS"]))
	except:
		pass
	if(request.method == 'POST'):
		password = request.form['_password1']+request.form['_password2']+request.form['_password3']+request.form['_password4']+request.form['_password5']
		try:
			output = decryptImage(path = IMAGE, password = password)
			print(output, len(output))
		except:
			pass
		if output == 'ERROR': 
			jls_extract_var = render_template('unencripted-image.html')
		else: 
			jls_extract_var = render_template('decrypt-image.html', _content_ = output)

		return jls_extract_var	

# home.html -> image-selected.html -> encryption-passcode.html -> encrypt-image.html -> download-image.html
@app.route('/image-operation', methods=['GET', 'POST'])
def image_operation():
	global PASSWORD
	try:
		os.chdir(str(app.config["Image_UPLOADS"]))
	except:
		pass
	if(request.method == 'POST'):
		rawText=request.form['rawtext']
		try:
			factor = round(encryptImage(path = IMAGE, save_as = IMAGE, text = rawText, password=PASSWORD)*100, 4)
			PASSWORD = "#"
		except:
			pass
		return render_template('download-image.html', _coeff_ = factor)	    

# home.html -> image-selected.html -> download-cleared-image.html
@app.route('/clear-image', methods=['GET', 'POST'])
def clear_operation():
	try:
		os.chdir(str(app.config["Image_UPLOADS"]))
	except:
		pass
	if(request.method == 'POST'):
		try:
			clearImage(path = IMAGE, save_as = IMAGE)
		except:
			pass
		return render_template('download-cleared-image.html')	   

if(__name__ == '__main__'):
	#ui.run()                   # running the app in app-mode
	app.run(debug = True)       # running the app in localhost
