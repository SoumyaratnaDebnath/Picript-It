from PIL import Image
import numpy

# takes a character and returns a string of its binary representation
def getBinary(char):
    x = bin(ord(char))[2:]
    for i in range(8-len(x)): x='0'+x
    return x

# for appending blank-space to non-required bytes
def createTextList(txt, size):
    for i in range(int(size-len(txt))-5) : txt += ' '
    return txt

# returns the maxlength of the string that can be encoded in the image (excluding the pointer at the beginning and the end)
def get_maxLength(path):
    img = Image.open(path)
    imgArr = numpy.array(img, dtype=numpy.uint8)
    maxLen = int(imgArr.size/8) - 12
    return maxLen

# for encrypting the image with the text
def encryptImage(path, save_as, text, password):
    # opening the image as a numpy-array
    img = Image.open(path)
    imgArr = numpy.array(img, dtype=numpy.uint8)
    orArr = imgArr.copy()

    # encripting the signature using vernam cipher
    signature =  encrypt_with_vernam_cipher(password, "_SRD_")

    # encripting data with playfair cipher
    Text = signature + createTextList(encrypt_with_playfair_cipher(password, text + "%SRD%"), imgArr.size/8)

    # encrypting the image with the data
    DataPoint = 0
    TextPoint = -1
    for x in range(imgArr.shape[0]):
        for y in range(imgArr.shape[1]):
            for z in range(imgArr.shape[2]):
                
                # image refreshing phase
                if imgArr[x][y][z] % 2 != 0 : imgArr[x][y][z] -= 1 
                    
                # image encrypting phase
                if DataPoint % 8 == 0 : TextPoint += 1
                if TextPoint < len(Text):
                    # writing the data
                    ch = int(getBinary(Text[TextPoint])[DataPoint % 8])
                    if ch == 1 : imgArr[x][y][z] += ch
                DataPoint+=1

    # converting array back to image   
    img = Image.fromarray(imgArr, 'RGB')
    img.save(save_as)
    corCoeff = numpy.corrcoef(orArr.reshape(orArr.size),imgArr.reshape(imgArr.size))[0][1]

    # returning the value of correlation coeff
    return corCoeff

# for validating the encription based on the signature and password
def validateEncryption(imgArr, password):
    Text = ''
    buf_txt = ''  
    DataPoint = 0 
    # searching for the signature
    for x in range(imgArr.shape[0]):
        for y in range(imgArr.shape[1]):
            for z in range(imgArr.shape[2]):
                if DataPoint%8 == 0: 
                    try:
                        # reading the data
                        ch = chr(int(buf_txt,2))
                        Text += ch
                    except:
                        pass
                    buf_txt = ''
                else:
                    if imgArr[x][y][z] % 2 == 0 : buf_txt += '0'
                    else: buf_txt += '1'
                DataPoint+=1
                if(DataPoint>40): 
                    # validating signature using vernam cipher
                    return derypt_with_vernam_cipher(password, Text) == '_SRD_'

# for decrypting the image
def decryptImage(path, password):
    # opening image as a numpy-array
    img = Image.open(path)
    imgArr = numpy.asarray(img)
    
    # validating the encryption
    if not validateEncryption(imgArr, password) : return 'ERROR'
    
    Text = ''
    buf_txt = ''  
    end_txt = ''
    end_ptr = 0
    DataPoint = 0 

    # reading the data
    for x in range(imgArr.shape[0]):
        for y in range(imgArr.shape[1]):
            for z in range(imgArr.shape[2]):
                if DataPoint > 40:
                    if DataPoint%8 == 0: 
                        try:
                            # reading the data
                            ch = chr(int(buf_txt,2))
                            if ch == '%': end_ptr += 1 
                            Text += ch
                            if end_ptr != 0 : end_txt += ch
                            if end_ptr == 2 :
                                # checking for the delimeter
                                # returning the playfair decipherd data
                                if decrypt_with_playfair_cipher(password, end_txt) == '%SRD%' : return decrypt_with_playfair_cipher(password, Text[:-5])
                        except:
                            pass
                        buf_txt = ''
                    else:
                        if imgArr[x][y][z] % 2 == 0 : buf_txt += '0'
                        else: buf_txt += '1'
                DataPoint+=1
    # auxillary return statement (the flow will not come to this point ever)
    return decrypt_with_playfair_cipher(password, Text)

# for clearing the encription
def clearImage(path, save_as):
    # opening the image as an array
    img = Image.open(path)
    imgArr = numpy.array(img, dtype=numpy.uint8)
    
    # remobving the signature by hard-coding
    imgArr[0][0][0]=0
    imgArr[0][0][1]=0
    imgArr[0][0][2]=0
    imgArr[0][1][0]=0
    imgArr[0][1][1]=0
    imgArr[0][1][2]=0
 
    # converting array back to image
    img = Image.fromarray(imgArr, 'RGB')
    img.save(save_as)

# encription using playfair cipher
def encrypt_with_playfair_cipher(Passcode, Text):
    Reference = 'abcdefghijklmnopqrstuvwxyz'
    Module = ""

    # iterting over passowrd for creating encription schema
    for i in Passcode:
        if i.isalpha():
            if i.lower() not in Module: Module+=i.lower()
    for i in Reference:
        if i.isalpha():
            if i.lower() not in Module: Module+=i.lower()

    Encripted_Text = ""

    # encripting the data other than signature
    for i in Text:
        if i.isalpha():
            if i.islower() : Encripted_Text += Module[Reference.index(i.lower())]
            else : Encripted_Text += Module[Reference.index(i.lower())].upper()
        else : Encripted_Text += i

    return Encripted_Text

# decripting using playfair cipher
def decrypt_with_playfair_cipher(Passcode, Encripted_Text):
    Reference = 'abcdefghijklmnopqrstuvwxyz'
    Module = ""

    # iterting over passowrd for creating decription schema
    for i in Passcode:
        if i.isalpha():
            if i.lower() not in Module: Module+=i.lower()
    for i in Reference:
        if i.isalpha():
            if i.lower() not in Module: Module+=i.lower()

    Decripted_Text = ""

    # decripting the data other than the signature
    for i in Encripted_Text:
        if i.isalpha():
            if i.islower() : Decripted_Text += Reference[Module.index(i.lower())]
            else : Decripted_Text += Reference[Module.index(i.lower())].upper()
        else : Decripted_Text += i

    return Decripted_Text

# decripting the signature using vernam cipher using the password
def derypt_with_vernam_cipher(Password, Text):
    decrypted_text = ''
    for i in range(len(Text)):
        decrypted_text += chr((ord(Text[i]) - ord(Password[i]))%128)
    return decrypted_text

# encripting the signature using vernam cipher using the password
def encrypt_with_vernam_cipher(Password, Text):
    encrypted_text = ''
    for i in range(len(Text)):
        encrypted_text += chr((ord(Text[i]) + ord(Password[i]))%128)
    return encrypted_text

